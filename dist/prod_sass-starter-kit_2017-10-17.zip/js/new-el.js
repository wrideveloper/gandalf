// var NewElement = Object.create(HTMLElement.prototype);
//   NewElement.createdCallback = function() {
//   this.innerHTML = "<p>Hallo, kenalin saya element baru!</p>";
//   };
// var NewEl = document.registerElement('new-el', {prototype: NewElement});

// var link = document.querySelector('link[rel="import"]');

// link.addEventListener('load',function(e){
//       var importedDoc = link.import; 
// });